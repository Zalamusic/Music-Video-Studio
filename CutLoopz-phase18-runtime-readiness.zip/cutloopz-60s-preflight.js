import { createGenerationTimeline } from './cutloopz-generation-timeline.js';
import { buildPerformanceDispatch } from './cutloopz-performance-dispatch.js';

// Offline bridge: explicit editorial directions only, no Director or provider calls.
export function preflight60({ scenes, vocalRanges, approved = false, lookCount } = {}) {
 if (lookCount !== 6) throw new Error('Six reference photos required.');
 if (!Array.isArray(scenes) || scenes.length !== 5) throw new Error('Five editorial scenes required.');
 const timeline = createGenerationTimeline({productionPlan:{songSeconds:60,manifest:{shots:scenes}},segmentSeconds:5});
 if (timeline.segments.length !== 12 || timeline.segments.some(s=>s.durationSeconds!==5)) throw new Error('Scene boundaries must align with five-second rendering segments.');
 const dispatch = buildPerformanceDispatch({timeline,vocalRanges,approval:approved});
 return {timeline,dispatch,renderEnabled:false, blockers:['Audio-driven pilot is not wired into unified rendering','Live identity and continuity verification required'], paidCalls:0};
}
