import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createCinematicEdit} from './cinematic-editing-engine.js';
test('real FFmpeg fixture: unique clips, no loops, soundtrack present',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'strict-edit-'));
 try {
 const a=path.join(dir,'a.mp4'),b=path.join(dir,'b.mp4'),song=path.join(dir,'song.wav'),outputFile=path.join(dir,'out.mp4');
 const ff=(...args)=>execFileSync('ffmpeg',['-loglevel','error','-y',...args]);
 for(const [file,color] of [[a,'red'],[b,'blue']]) ff('-f','lavfi','-i',`color=${color}:s=160x90:r=24:d=1`,'-c:v','libx264',file);
 ff('-f','lavfi','-i','sine=frequency=440:duration=3',song);
 const base={sceneFiles:[a,b],songFile:song,outputFile,songSeconds:2,format:'landscape'};
 await assert.rejects(createCinematicEdit({...base,sceneFiles:[a,a]}),/Duplicate/);
 await assert.rejects(createCinematicEdit({...base,plan:{scenes:[{durationSeconds:2}]}}),/unique source/);
 await assert.rejects(createCinematicEdit({...base,plan:{scenes:[{durationSeconds:1.5},{durationSeconds:.5}]}}),/Insufficient source/);
 const result=await createCinematicEdit(base);assert.equal(result.scenesUsed,2);assert.ok(Math.abs(result.durationSeconds-2)<.1);
 const streams=JSON.parse(execFileSync('ffprobe',['-v','error','-show_streams','-of','json',outputFile])).streams;assert.ok(streams.some(s=>s.codec_type==='audio'));assert.ok(streams.some(s=>s.codec_type==='video'));
 }finally{await rm(dir,{recursive:true,force:true});}
});
