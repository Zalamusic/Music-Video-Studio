import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const digest=b=>createHash('sha256').update(b).digest('hex');
export function checkProviderConfiguration(routing,env=process.env){
 const types=new Set(routing.segments.map(s=>s.adapter));
 if(types.has('performance-pilot')&&(!env.FAL_KEY?.trim()||env.CUTLOOPZ_PERFORMANCE_PILOT_ENABLED!=='true'))throw Error('Performance pilot configuration missing');
 if(types.has('createRunPodVideo')){if(!env.ZALA_GPU_API_KEY?.trim()||!env.ZALA_GPU_ENDPOINT)throw Error('RunPod configuration missing');const u=new URL(env.ZALA_GPU_ENDPOINT);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)throw Error('Invalid RunPod endpoint');}
}
export async function verifyHostedReferences({photos,urls,fetcher=fetch}){
 if(photos.length!==6||urls.length!==6)throw Error('Six references required');
 for(let i=0;i<6;i++){
 const expected=await readFile(photos[i]);const response=await fetcher(urls[i],{redirect:'error',signal:AbortSignal.timeout(15000)});
 if(!response.ok||!response.body)throw Error(`Reference ${i+1} unavailable`);
 const reader=response.body.getReader();let size=0;const hash=createHash('sha256');try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>expected.length)throw Error(`Reference ${i+1} mismatch`);hash.update(value);}}finally{await reader.cancel();}
 if(size!==expected.length||hash.digest('hex')!==digest(expected))throw Error(`Reference ${i+1} mismatch`);
 }
}
