import {createSavedJob} from './cutloopz-job-control.js';
import {buildRenderRouting} from './cutloopz-render-routing.js';
import express from 'express';
import multer from 'multer';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {prepareOfficialPilotDryRun} from './cutloopz-offline-integration.js';
// Administrator-only preparation endpoint. No provider calls or paid execution.
export function register60sPreflight({app,isVideoAdmin}) {
 const router=express.Router();
 const upload=multer({storage:multer.memoryStorage(),limits:{files:7,fileSize:30*1024*1024,fields:1,fieldSize:128*1024}});
 router.post('/preflight',(req,res,next)=>isVideoAdmin(req)?next():res.status(403).json({ok:false}),upload.fields([{name:'song',maxCount:1},{name:'photos',maxCount:6}]),async(req,res)=>{
  let dir;
  try {
   const song=req.files?.song?.[0], photos=req.files?.photos;
   if(!song||photos?.length!==6||photos.some(p=>p.size>12*1024*1024))throw Error('One song and six photos required');
   const {scenes,vocalRanges,approved,lookBySegment}=JSON.parse(req.body.plan);
   dir=await mkdtemp(path.join(tmpdir(),'cutloopz60-'));
   const songPath=path.join(dir,'song'); await writeFile(songPath,song.buffer);
   const photoPaths=await Promise.all(photos.map(async(p,i)=>{const f=path.join(dir,`photo-${i}`);await writeFile(f,p.buffer);return f;}));
   const result=await prepareOfficialPilotDryRun({scenes,vocalRanges,approved:approved===true,song:songPath,photos:photoPaths,lookBySegment,outDir:dir});
   const routing=buildRenderRouting({dispatch:result.plan.dispatch,requests:result.requests,lookBySegment});
   const jobId=process.env.CUTLOOPZ_PRODUCTION_ROOT?await createSavedJob({root:process.env.CUTLOOPZ_PRODUCTION_ROOT,song:song.buffer,photos:photos.map(p=>p.buffer),plan:{scenes,vocalRanges,approved,lookBySegment}}):null;
   res.json({ok:true,jobId,routing,plan:result.plan,requests:result.requests.map(r=>({number:r.number,originalStartSeconds:r.originalStartSeconds,route:r.route,allowPaidTest:r.form.get('allowPaidTest')})),renderEnabled:false,paidCalls:0});
  }catch(e){res.status(422).json({ok:false,error:String(e.message).slice(0,300)});}finally{if(dir)await rm(dir,{recursive:true,force:true});}
 });
 app.use('/api/unified-production-60s',router);
}
