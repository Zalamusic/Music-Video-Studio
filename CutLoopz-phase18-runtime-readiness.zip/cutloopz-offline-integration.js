import {readFile} from 'node:fs/promises';
import {preflight60} from './cutloopz-60s-preflight.js';
import {preparePerformanceInputs} from './cutloopz-performance-preparation.js';
import {applyCharacterIdentityToPrompt} from './character-identity-engine.js';
import {captureSceneFrames} from './visual-continuity-engine.js';
import {scoreQuality} from './realism-engine.js';
import {createCinematicEdit} from './cinematic-editing-engine.js';
// Explicitly offline: returns actual pilot multipart payloads, never submits them.
export async function prepareOfficialPilotDryRun({scenes,vocalRanges,approved,song,photos,lookBySegment,outDir}) {
 const plan=preflight60({scenes,vocalRanges,approved,lookCount:photos?.length});
 const prepared=await preparePerformanceInputs({dispatch:plan.dispatch,song,photos,lookBySegment,outDir});
 const requests=[];
 for(const input of prepared.inputs){
  const form=new FormData();
  form.append('song',new Blob([await readFile(input.audio)],{type:'audio/wav'}),'section.wav');
  form.append('photo',new Blob([await readFile(input.photo)]),'reference');
  form.append('startSeconds','0'); // already sliced at original timeline offset
  form.append('guidance',applyCharacterIdentityToPrompt(input.guidance||'',{hasReferencePhoto:true}).slice(0,900));
  form.append('allowPaidTest','no');
  requests.push({number:input.number,originalStartSeconds:input.startSeconds,route:'/api/performance-pilot/test',form});
 }
 return {plan,requests,paidCalls:0,renderEnabled:false};
}
// Review and assembly of supplied footage only; no synthetic quality scores.
export async function reviewAndAssemble({sceneFiles,songFile,outputFile,jobDirectory,metrics,approved=false,format='vertical'}){
 if(!Array.isArray(sceneFiles)||sceneFiles.length!==12)throw Error('Twelve ordered raw clips required');
 const samples=[];
 for(const [i,videoFile] of sceneFiles.entries()) samples.push(await captureSceneFrames({jobDirectory,sceneNumber:i+1,videoFile,durationSeconds:5}));
 if(!approved||!metrics)return {status:'REVIEW_REQUIRED',samples,paidCalls:0};
 const score=scoreQuality(metrics);
 const edit=await createCinematicEdit({sceneFiles,songFile,outputFile,songSeconds:60,format,workDirectory:jobDirectory});
 return {status:'ASSEMBLED_NOT_VISUALLY_VERIFIED',samples,score,edit,paidCalls:0};
}
