import {applyCharacterIdentityToPrompt} from './character-identity-engine.js';
// No network, uploads or execution. Both official adapter contracts are represented.
export function buildRenderRouting({dispatch,requests,lookBySegment,format='vertical'}) {
 if(dispatch?.readyForAdapterReview!==true||dispatch?.approvedVocalTimecodes!==true||dispatch.songSeconds!==60||dispatch.segments?.length!==12) throw Error('Approved 60-second dispatch required');
 if(!['vertical','landscape'].includes(format)) throw Error('Invalid format');
 const map=new Map(requests.map(r=>[r.number,r]));
 if(map.size!==requests.length) throw Error('Duplicate performance request');
 const segments=dispatch.segments.map((s,i)=>{
  if(s.number!==i+1||s.startSeconds!==i*5||s.endSeconds!==(i+1)*5||s.status!=='planned') throw Error('Invalid segment');
  const look=lookBySegment?.[s.number];
  if(!Number.isInteger(look)||look<0||look>5) throw Error(`Explicit reference required for segment ${s.number}`);
  const rawFile=`segment-${String(s.number).padStart(3,'0')}.mp4`;
  if(s.type==='performance') {
   const r=map.get(s.number);
   if(!r||r.originalStartSeconds!==s.startSeconds||r.route!=='/api/performance-pilot/test'||r.form.get('allowPaidTest')!=='no') throw Error('Invalid performance request');
   map.delete(s.number);
   return {number:s.number,look,rawFile,adapter:'performance-pilot',route:r.route,originalStartSeconds:s.startSeconds};
  }
  if(s.type!=='cinematic') throw Error('Unsupported segment type');
  return {number:s.number,look,rawFile,adapter:'createRunPodVideo',options:{prompt:applyCharacterIdentityToPrompt(s.prompt,{hasReferencePhoto:true}).slice(0,2000),seconds:5,format},requires:['approved HTTPS reference URL','private output path']};
 });
 if(map.size) throw Error('Unexpected performance requests');
 return {segments,renderEnabled:false,paidCalls:0};
}
