import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,writeFile,readFile,copyFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {executeProduction} from './cutloopz-provider-execution.js';
const run=promisify(execFile);
test('provider simulation: authorization, interruption, resume, twelve clips, master',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'cl-provider-'));
 const old={...process.env};
 try{
 const photos=[],segments=[],requests=[],fixtures=[];
 for(let i=0;i<6;i++){const p=path.join(dir,`photo${i}`);await writeFile(p,`fixture ${i}`);photos.push(p);}
 for(let i=0;i<12;i++){const file=path.join(dir,`fixture${i}.mp4`);await run('ffmpeg',['-v','error','-f','lavfi','-i',`color=c=0x${(0x102030+i*0x090705).toString(16)}:s=160x90:r=24:d=5`,'-c:v','libx264','-pix_fmt','yuv420p',file]);fixtures.push(file);segments.push({number:i+1,rawFile:`segment-${String(i+1).padStart(3,'0')}.mp4`,look:i%6,adapter:i%2?'performance-pilot':'createRunPodVideo',options:{seconds:5}});if(i%2){const form=new FormData();form.set('allowPaidTest','no');requests.push({number:i+1,form});}}
 const songFile=path.join(dir,'song.wav');await run('ffmpeg',['-v','error','-f','lavfi','-i','sine=frequency=440:duration=60',songFile]);
 let submissions=0,visuals=0,interrupt=true;
 const adapters={async submit(r){submissions++;return r.number;},async finish(id,file){if(interrupt){interrupt=false;throw Error('simulated interruption');}await copyFile(fixtures[id-1],file);},async visual(o){visuals++;const n=Number(path.basename(o.outputPath).match(/\d+/)[0]);await copyFile(fixtures[n-1],o.outputPath);}};
 const args={routing:{renderEnabled:false,segments},requests,photos,referenceUrls:photos.map((_,i)=>`https://example.invalid/${i}`),songFile,jobDirectory:path.join(dir,'job'),format:'landscape',approval:'AUTHORIZE_12_SEGMENTS',adapters};
 process.env.ENABLE_PAID_GENERATION='false';process.env.CUTLOOPZ_PRODUCTION_EXECUTION='true';await assert.rejects(executeProduction(args),/authorization/);assert.equal(submissions+visuals,0);
 process.env.ENABLE_PAID_GENERATION='true';await assert.rejects(executeProduction(args),/simulated interruption/);assert.equal(submissions,1);assert.equal(visuals,1);
 const state=JSON.parse(await readFile(path.join(args.jobDirectory,'execution.json')));assert.equal(state.segments[1].status,'complete');assert.equal(state.segments[2].status,'queued');
 const result=await executeProduction(args);assert.equal(submissions,6);assert.equal(visuals,6);assert.equal(result.status,'REVIEW_REQUIRED');assert.equal(result.rawFiles.length,12);assert.equal(result.providerSubmissions,12);assert.equal(result.paidCalls,null); const again=await executeProduction(args);assert.equal(again.providerSubmissions,12);assert.equal(submissions+visuals,12);
 const p=JSON.parse((await run('ffprobe',['-v','error','-show_streams','-of','json',result.outputFile])).stdout);for(const type of ['audio','video'])assert.ok(Math.abs(Number(p.streams.find(s=>s.codec_type===type).duration)-60)<0.15);
 }finally{for(const k of ['ENABLE_PAID_GENERATION','CUTLOOPZ_PRODUCTION_EXECUTION']){if(old[k]===undefined)delete process.env[k];else process.env[k]=old[k];}await rm(dir,{recursive:true,force:true});}
});
