import test from 'node:test';import assert from 'node:assert/strict';import {assembleRawProduction} from './cutloopz-raw-assembly.js';
const routing={renderEnabled:false,segments:Array.from({length:12},(_,i)=>({number:i+1,adapter:'createRunPodVideo',rawFile:`segment-${String(i+1).padStart(3,'0')}.mp4`}))};
test('reject incomplete production',async()=>{await assert.rejects(assembleRawProduction({routing,clips:[]}),/Twelve/)});
test('reject mismatched routing before media access',async()=>{await assert.rejects(assembleRawProduction({routing,clips:Array.from({length:12},()=>({number:99}))}),/mismatch/)});
test('reject unsafe format',async()=>{await assert.rejects(assembleRawProduction({routing,clips:Array(12),format:'other'}),/format/)});
