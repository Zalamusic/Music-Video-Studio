import { promises as fs } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
const run=promisify(execFile);
// Offline only: prepare inputs for the existing single-reference performance pilot.
export async function preparePerformanceInputs({dispatch,song,photos,lookBySegment,outDir}) {
 if(dispatch?.approvedVocalTimecodes!==true || dispatch?.readyForAdapterReview!==true || !Array.isArray(dispatch.segments)) throw Error('Approved dispatch required');
 if(!Array.isArray(photos)||photos.length!==6) throw Error('Six photos required');
 if(dispatch.songSeconds!==60 || dispatch.segments.length!==12) throw Error('60-second dispatch required');
 for(const [i,s] of dispatch.segments.entries()) {
  if(s.number!==i+1||s.startSeconds!==i*5||s.endSeconds!==(i+1)*5||s.durationSeconds!==5||s.status!=='planned'||!['performance','cinematic'].includes(s.type)) throw Error('Invalid segment');
  if(s.type==='performance' && (!Number.isInteger(lookBySegment?.[s.number])||lookBySegment[s.number]<0||lookBySegment[s.number]>5||s.audioStartSeconds!==s.startSeconds||s.audioEndSeconds!==s.endSeconds)) throw Error('Explicit reference and audio range required');
 }
 const probe=async f=>JSON.parse((await run('ffprobe',['-v','error','-show_entries','format=duration:stream=codec_type','-of','json',f])).stdout);
 const p=await probe(song); if(Number(p.format?.duration)<60||!p.streams?.some(s=>s.codec_type==='audio')) throw Error('Full 60-second audio required');
 for(const photo of photos) {const b=await fs.readFile(photo); if(!(b.length>=16&&(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))||b.subarray(0,3).equals(Buffer.from([255,216,255]))||(b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP')))) throw Error('Invalid reference image');}
 await fs.mkdir(outDir,{recursive:true});
 const dir=await fs.mkdtemp(path.join(outDir,'performance-'));
 try {const inputs=[]; for(const s of dispatch.segments.filter(s=>s.type==='performance')) {
 const audio=path.join(dir,`segment-${s.number}.wav`);
 await run('ffmpeg',['-v','error','-ss',String(s.startSeconds),'-i',song,'-t','5','-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',audio]);
 if(Math.abs(Number((await probe(audio)).format.duration)-5)>0.02) throw Error('Incorrect audio duration');
 inputs.push({number:s.number,audio,photo:photos[lookBySegment[s.number]],guidance:s.prompt,startSeconds:s.startSeconds,allowPaidTest:'no'});
 } return {inputs,paidCalls:0,renderEnabled:false};} catch(e){await fs.rm(dir,{recursive:true,force:true});throw e;}
}
