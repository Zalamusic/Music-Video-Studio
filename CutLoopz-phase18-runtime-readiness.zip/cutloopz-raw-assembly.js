import {mkdir,copyFile,writeFile,readFile} from 'node:fs/promises';
import {constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import path from 'node:path';
import {createCinematicEdit} from './cinematic-editing-engine.js';
const run=promisify(execFile);
// Import completed provider clips only. Never submit a paid request.
export async function assembleRawProduction({routing,clips,songFile,jobDirectory,format='vertical',providerSubmissions=null}) {
 if(routing?.renderEnabled!==false||routing?.segments?.length!==12||clips?.length!==12) throw Error('Twelve routed clips required');
 if(!['vertical','landscape'].includes(format)) throw Error('Invalid format');
 const hashes=new Set();
 for(let i=0;i<12;i++) {
  const s=routing.segments[i], c=clips[i];
  if(s.number!==i+1||c.number!==s.number||c.adapter!==s.adapter||!['performance-pilot','createRunPodVideo'].includes(s.adapter)||s.rawFile!==`segment-${String(i+1).padStart(3,'0')}.mp4`) throw Error('Clip routing mismatch');
  const p=JSON.parse((await run('ffprobe',['-v','error','-show_streams','-show_format','-of','json',c.file])).stdout);
  const v=p.streams.find(s=>s.codec_type==='video');
  if(!v||!Number.isFinite(Number(v.duration))||Math.abs(Number(v.duration)-5)>0.045) throw Error('Expected five-second video stream');
  const hash=createHash('sha256').update(await readFile(c.file)).digest('hex');
  if(hashes.has(hash)) throw Error('Duplicate raw footage'); hashes.add(hash);
 }
 await mkdir(jobDirectory,{mode:0o700});
 const raw=path.join(jobDirectory,'raw'); await mkdir(raw,{mode:0o700});
 const sceneFiles=[];
 for(let i=0;i<12;i++){const dest=path.join(raw,routing.segments[i].rawFile);await copyFile(clips[i].file,dest,constants.COPYFILE_EXCL);sceneFiles.push(dest);}
 const outputFile=path.join(jobDirectory,'master.mp4');
 const result=await createCinematicEdit({sceneFiles,songFile,outputFile,songSeconds:60,format});
 const manifest={status:'REVIEW_REQUIRED',paidCalls:null,providerSubmissions,rawFiles:sceneFiles.map(f=>path.basename(f)),outputFile,durationSeconds:result.durationSeconds};
 await writeFile(path.join(jobDirectory,'manifest.json'),JSON.stringify(manifest,null,2),{flag:'wx'});return manifest;
}
