import {mkdir,readFile,writeFile,rename,open,unlink,copyFile,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {createRunPodVideo} from './runpod-video-engine.js';
import {assembleRawProduction} from './cutloopz-raw-assembly.js';
const hash=b=>createHash('sha256').update(b).digest('hex');
// Operator-only local runner. No automatic retry of ambiguous submissions.
export async function executeProduction({routing,requests,photos,referenceUrls,songFile,jobDirectory,format='vertical',approval,adapters}) {
 if(process.env.ENABLE_PAID_GENERATION!=='true'||process.env.CUTLOOPZ_PRODUCTION_EXECUTION!=='true'||approval!=='AUTHORIZE_12_SEGMENTS')throw Error('Explicit execution authorization required');
 if(routing?.renderEnabled!==false||routing.segments?.length!==12||photos?.length!==6)throw Error('Invalid preflight');
 const reqs=new Map(requests.map(r=>[r.number,r]));
 for(const [i,s] of routing.segments.entries()){
 if(s.number!==i+1||s.rawFile!==`segment-${String(i+1).padStart(3,'0')}.mp4`||!Number.isInteger(s.look)||s.look<0||s.look>5)throw Error('Invalid routing');
 if(s.adapter==='performance-pilot'){if(!reqs.get(s.number)||reqs.get(s.number).form.get('allowPaidTest')!=='no')throw Error('Missing prepared request');}
 else if(s.adapter==='createRunPodVideo'){const u=new URL(referenceUrls[s.look]);if(u.protocol!=='https:'||u.username||u.password||s.options.seconds!==5)throw Error('Invalid visual request');}
 else throw Error('Unknown adapter');
 }
 const fingerprint=hash(JSON.stringify({routing,format,referenceUrls,photos:await Promise.all(photos.map(async p=>hash(await readFile(p)))),song:hash(await readFile(songFile)),requests:await Promise.all(requests.map(async r=>[r.number,...await Promise.all([...r.form.entries()].map(async ([k,v])=>[k,typeof v==='string'?v:hash(Buffer.from(await v.arrayBuffer()))]))]))}));
 await mkdir(jobDirectory,{recursive:true,mode:0o700});
 const lock=path.join(jobDirectory,'execution.lock'); const handle=await open(lock,'wx',0o600);
 const journal=path.join(jobDirectory,'execution.json');
 try{
 let state;try{state=JSON.parse(await readFile(journal,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;state={fingerprint,segments:{}};}
 if(state.fingerprint!==fingerprint)throw Error('Inputs changed; refusing resume');
 const save=async()=>{await writeFile(journal+'.tmp',JSON.stringify(state,null,2),{mode:0o600});await rename(journal+'.tmp',journal);};
 const inputDir=path.join(jobDirectory,'inputs');await mkdir(inputDir,{recursive:true,mode:0o700});
 await copyFile(songFile,path.join(inputDir,'song'));for(let i=0;i<6;i++)await copyFile(photos[i],path.join(inputDir,`photo-${i}`));
 await save();const clips=[];
 for(const s of routing.segments){const file=path.join(jobDirectory,s.rawFile);let entry=state.segments[s.number];
 if(entry?.status==='complete'){if(hash(await readFile(file))!==entry.hash)throw Error('Completed clip changed');}
 else {
 if(entry?.status==='submitting')throw Error('Ambiguous submission; reconcile provider manually before continuing');
 if(!entry){entry=state.segments[s.number]={status:'submitting'};await save();
 if(s.adapter==='performance-pilot'){entry.id=await adapters.submit(reqs.get(s.number));entry.status='queued';await save();}
 else {await adapters.visual({...s.options,imageUrl:referenceUrls[s.look],outputPath:file});}}
 if(s.adapter==='performance-pilot'){await adapters.finish(entry.id,file);}
 entry.hash=hash(await readFile(file));entry.status='complete';await save();}
 clips.push({number:s.number,adapter:s.adapter,file});}
 const assemblyDirectory=path.join(jobDirectory,'assembly');
 // Rebuild only derived outputs; provider originals remain untouched.
 await rm(assemblyDirectory,{recursive:true,force:true});
 return await assembleRawProduction({routing,clips,providerSubmissions:Object.keys(state.segments).length,songFile:path.join(inputDir,'song'),jobDirectory:path.join(jobDirectory,'assembly'),format});
 }finally{await handle.close();await unlink(lock);}
}
export function officialAdapters({port,adminKey}){
 if(!Number.isInteger(port)||port<1||port>65535||!adminKey)throw Error('Local pilot configuration required');
 const base=`http://127.0.0.1:${port}/api/performance-pilot/test`;const headers={'X-Video-Admin-Key':adminKey};
 const call=async(url,options={})=>{const r=await fetch(url,{...options,headers,redirect:'error',signal:AbortSignal.timeout(120000)});if(!r.ok)throw Error(`Pilot HTTP ${r.status}`);return r;};
 return {visual:createRunPodVideo,async submit(request){const form=new FormData();for(const [k,v] of request.form.entries())form.append(k,v);form.set('allowPaidTest','yes');const j=await (await call(base,{method:'POST',body:form})).json();if(j.status!=='queued'||!j.id)throw Error('Pilot did not confirm queued request');return j.id;},async finish(id,file){if(!/^[0-9a-f-]{36}$/i.test(id))throw Error('Invalid pilot ID');for(let i=0;i<180;i++){const j=await (await call(`${base}/${id}`)).json();if(j.status==='failed')throw Error('Pilot failed; manual reconciliation required');if(j.status==='ready'){const r=await call(`${base}/${id}/video`);await writeFile(file,Buffer.from(await r.arrayBuffer()));return;}await new Promise(r=>setTimeout(r,10000));}throw Error('Pilot still pending; resume with saved ID');}};
}
