import {mkdir,mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const run=promisify(execFile);
export async function probeRuntime({env=process.env,fetcher=fetch,command=run}={}){
 const checks={};
 for(const tool of ['ffmpeg','ffprobe']){try{await command(tool,['-version'],{timeout:5000});checks[tool]=true;}catch{checks[tool]=false;}}
 let dir;try{const root=env.CUTLOOPZ_PRODUCTION_ROOT;if(!root||!path.isAbsolute(root))throw Error();await mkdir(root,{recursive:true,mode:0o700});dir=await mkdtemp(path.join(root,'.readiness-'));const f=path.join(dir,'probe');await writeFile(f,'ready',{mode:0o600});checks.storageWritable=(await readFile(f,'utf8'))==='ready';}catch{checks.storageWritable=false;}finally{if(dir)await rm(dir,{recursive:true,force:true});}
 checks.performanceConfigured=Boolean(env.FAL_KEY?.trim()&&env.CUTLOOPZ_PERFORMANCE_PILOT_ENABLED==='true');
 checks.runpodConfigured=false;checks.runpodHealth=false;checks.runpodGenerationReady=false;
 try{const u=new URL(env.ZALA_GPU_ENDPOINT);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||!env.ZALA_GPU_API_KEY?.trim())throw Error();checks.runpodConfigured=true;u.pathname=u.pathname.replace(/\/$/,'')+'/health';const r=await fetcher(u.href,{method:'GET',redirect:'error',signal:AbortSignal.timeout(10000)});if(r.ok){const j=await r.json();checks.runpodHealth=j.ok===true&&j.status==='online';checks.runpodGenerationReady=checks.runpodHealth&&j.gpuGenerationReady===true;}}catch{}
 return {checks,paidSubmissions:0,performanceConnectivityVerified:false,persistentMountVerified:false,productionReady:false};
}
export function registerRuntimeReadiness({app,isVideoAdmin}){app.get('/api/unified-production-60s/readiness',async(req,res)=>{if(!isVideoAdmin(req))return res.status(403).json({ok:false});res.set('Cache-Control','no-store');try{res.json({ok:true,...await probeRuntime()});}catch{res.status(503).json({ok:false});}});}
