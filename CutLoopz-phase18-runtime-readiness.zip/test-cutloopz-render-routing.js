import test from 'node:test';import assert from 'node:assert/strict';import {buildRenderRouting} from './cutloopz-render-routing.js';
const dispatch={readyForAdapterReview:true,approvedVocalTimecodes:true,songSeconds:60,segments:Array.from({length:12},(_,i)=>({number:i+1,startSeconds:i*5,endSeconds:(i+1)*5,status:'planned',type:i===2?'performance':'cinematic',prompt:'fixture'}))};
const form=new FormData();form.set('allowPaidTest','no');const requests=[{number:3,originalStartSeconds:10,route:'/api/performance-pilot/test',form}];const lookBySegment=Object.fromEntries(Array.from({length:12},(_,i)=>[i+1,i%6]));const args={dispatch,requests,lookBySegment};
test('routes all twelve without execution',()=>{const r=buildRenderRouting(args);assert.equal(r.segments.length,12);assert.equal(r.segments[2].adapter,'performance-pilot');assert.equal(r.segments[0].adapter,'createRunPodVideo');assert.equal(new Set(r.segments.map(s=>s.rawFile)).size,12);assert.equal(r.paidCalls,0);assert.equal(r.renderEnabled,false)});
test('missing reference rejected',()=>assert.throws(()=>buildRenderRouting({...args,lookBySegment:{3:0}})));
test('missing performance request rejected',()=>assert.throws(()=>buildRenderRouting({...args,requests:[]})));
test('duplicate request rejected',()=>assert.throws(()=>buildRenderRouting({...args,requests:[...requests,...requests]})));
test('paid request rejected',()=>{const f=new FormData();f.set('allowPaidTest','yes');assert.throws(()=>buildRenderRouting({...args,requests:[{...requests[0],form:f}]}))});
test('unapproved rejected',()=>assert.throws(()=>buildRenderRouting({...args,dispatch:{...dispatch,approvedVocalTimecodes:false}})));
