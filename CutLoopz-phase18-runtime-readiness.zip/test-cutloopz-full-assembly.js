import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {assembleRawProduction} from './cutloopz-raw-assembly.js';
const run=promisify(execFile);
test('full 60-second offline assembly, twelve distinct raw clips and soundtrack',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'cl-full-'));
 try {
 const segments=[],clips=[];
 for(let i=0;i<12;i++){
 const rawFile=`segment-${String(i+1).padStart(3,'0')}.mp4`,file=path.join(dir,rawFile),adapter=i%2?'performance-pilot':'createRunPodVideo';
 await run('ffmpeg',['-v','error','-f','lavfi','-i',`color=c=0x${(0x102030+i*0x090705).toString(16)}:s=160x90:r=24:d=5`,'-c:v','libx264','-pix_fmt','yuv420p',file]);
 segments.push({number:i+1,rawFile,adapter});clips.push({number:i+1,file,adapter});
 }
 const songFile=path.join(dir,'song.wav');await run('ffmpeg',['-v','error','-f','lavfi','-i','sine=frequency=440:duration=60',songFile]);
 const jobDirectory=path.join(dir,'job');const result=await assembleRawProduction({routing:{renderEnabled:false,segments},clips,songFile,jobDirectory,format:'landscape'});
 assert.equal(result.status,'REVIEW_REQUIRED');assert.equal((await readdir(path.join(jobDirectory,'raw'))).length,12);
 const p=JSON.parse((await run('ffprobe',['-v','error','-show_streams','-of','json',result.outputFile])).stdout);
 for(const type of ['audio','video'])assert.ok(Math.abs(Number(p.streams.find(s=>s.codec_type===type).duration)-60)<0.15);
 }finally{await rm(dir,{recursive:true,force:true});}
});
